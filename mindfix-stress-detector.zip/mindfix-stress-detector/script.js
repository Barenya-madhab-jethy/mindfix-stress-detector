// script.js - MindFix Stress Pattern Detector

// ===== Application State & Configuration =====
const AppState = {
    currentDate: new Date(),
    userData: {
        dailyEntries: [],
        journalEntries: {},
        settings: {
            darkMode: false,
            focusTime: 25,
            breakTime: 5
        }
    },
    currentStressScore: 0,
    stressLevels: {
        calm: { min: 0, max: 30, color: '#4caf50', label: 'Calm' },
        moderate: { min: 31, max: 60, color: '#ff9800', label: 'Moderate' },
        high: { min: 61, max: 100, color: '#f44336', label: 'High' }
    },
    triggers: [
        { id: 'workload', name: 'Heavy Workload', count: 0 },
        { id: 'deadlines', name: 'Tight Deadlines', count: 0 },
        { id: 'social', name: 'Social Pressure', count: 0 },
        { id: 'sleep', name: 'Lack of Sleep', count: 0 },
        { id: 'screen', name: 'Excessive Screen Time', count: 0 }
    ],
    copingTips: {
        calm: [
            "Great job maintaining balance! Keep up your healthy routines.",
            "Your stress levels are well-managed. Consider meditation to maintain this state.",
            "Excellent work-life balance detected. Share your strategies with friends!"
        ],
        moderate: [
            "Try a 5-minute breathing exercise to reduce stress.",
            "Consider taking a short walk to clear your mind.",
            "Prioritize tasks and break them into smaller steps."
        ],
        high: [
            "Important: Take a 10-minute break immediately. Practice deep breathing.",
            "Consider talking to someone about your stress.",
            "Try the 20-20-20 rule: Every 20 minutes, look at something 20 feet away for 20 seconds."
        ]
    },
    timer: {
        isRunning: false,
        isFocusTime: true,
        minutes: 25,
        seconds: 0,
        intervalId: null
    },
    breathing: {
        isActive: false,
        isInhaling: true,
        intervalId: null
    }
};

// ===== DOM Elements =====
// Dashboard Elements
const currentDateEl = document.getElementById('currentDate');
const stressScoreEl = document.getElementById('stressScore');
const meterFillEl = document.getElementById('meterFill');
const streakCountEl = document.getElementById('streakCount');
const topTriggersEl = document.getElementById('topTriggers');
const dailyTipEl = document.getElementById('dailyTip');

// Check-in Form Elements
const moodSlider = document.getElementById('moodLevel');
const moodValueEl = document.getElementById('moodValue');
const sleepButtons = document.querySelectorAll('[data-value="poor"], [data-value="average"], [data-value="good"]');
const studyButtons = document.querySelectorAll('[data-value="low"], [data-value="medium"], [data-value="high"]');
const screenButtons = document.querySelectorAll('[data-value="low"], [data-value="medium"], [data-value="high"]');
const triggerCheckboxes = document.querySelectorAll('input[name="triggers"]');
const dailyNotesEl = document.getElementById('dailyNotes');
const checkinForm = document.getElementById('dailyCheckinForm');
const resetFormBtn = document.getElementById('resetFormBtn');
const quickCheckinBtn = document.getElementById('quickCheckinBtn');

// Preview Elements
const previewMoodEl = document.getElementById('previewMood');
const previewSleepEl = document.getElementById('previewSleep');
const previewStudyEl = document.getElementById('previewStudy');
const previewScreenEl = document.getElementById('previewScreen');
const previewTriggersEl = document.getElementById('previewTriggers');
const previewStressEl = document.getElementById('previewStress');

// Trends & Calendar Elements
const trendChartEl = document.getElementById('trendChart');
const timeRangeSelect = document.getElementById('timeRangeSelect');
const currentMonthYearEl = document.getElementById('currentMonthYear');
const prevMonthBtn = document.getElementById('prevMonthBtn');
const nextMonthBtn = document.getElementById('nextMonthBtn');
const calendarGridEl = document.getElementById('calendarGrid');
const triggerChartEl = document.getElementById('triggerChart');

// Analysis Elements
const patternsListEl = document.getElementById('patternsList');
const analyzePatternsBtn = document.getElementById('analyzePatternsBtn');

// Timer Elements
const timerMinutesEl = document.getElementById('timerMinutes');
const timerSecondsEl = document.getElementById('timerSeconds');
const timerModeEl = document.getElementById('timerMode');
const startTimerBtn = document.getElementById('startTimerBtn');
const pauseTimerBtn = document.getElementById('pauseTimerBtn');
const resetTimerBtn = document.getElementById('resetTimerBtn');
const focusTimeInput = document.getElementById('focusTime');
const breakTimeInput = document.getElementById('breakTime');

// Breathing Elements
const breathingCircleEl = document.getElementById('breathingCircle');
const breathTextEl = document.getElementById('breathText');
const startBreathingBtn = document.getElementById('startBreathingBtn');
const stopBreathingBtn = document.getElementById('stopBreathingBtn');

// Report & Goals Elements
const avgStressEl = document.getElementById('avgStress');
const bestDayEl = document.getElementById('bestDay');
const worstDayEl = document.getElementById('worstDay');
const stressTrendEl = document.getElementById('stressTrend');
const reportMessageEl = document.getElementById('reportMessage');
const generateReportBtn = document.getElementById('generateReportBtn');
const exportReportBtn = document.getElementById('exportReportBtn');

const sleepProgressEl = document.getElementById('sleepProgress');
const sleepProgressFillEl = document.getElementById('sleepProgressFill');
const screenProgressEl = document.getElementById('screenProgress');
const screenProgressFillEl = document.getElementById('screenProgressFill');
const consistencyProgressEl = document.getElementById('consistencyProgress');
const consistencyProgressFillEl = document.getElementById('consistencyProgressFill');
const updateGoalsBtn = document.getElementById('updateGoalsBtn');

const journalEntryEl = document.getElementById('journalEntry');
const saveJournalBtn = document.getElementById('saveJournalBtn');
const viewJournalBtn = document.getElementById('viewJournalBtn');
const alertsListEl = document.getElementById('alertsList');

// Footer Elements
const darkModeToggle = document.getElementById('darkModeToggle');
const clearDataBtn = document.getElementById('clearDataBtn');
const exportAllBtn = document.getElementById('exportAllBtn');

// ===== Utility Functions =====
function formatDate(date) {
    return date.toLocaleDateString('en-US', {
        weekday: 'long',
        year: 'numeric',
        month: 'long',
        day: 'numeric'
    });
}

function getDateKey(date) {
    return date.toISOString().split('T')[0];
}

function showToast(message, type = 'info') {
    const toastContainer = document.getElementById('toastContainer');
    const toast = document.createElement('div');
    toast.className = `toast ${type}`;
    toast.innerHTML = `
        <i class="fas fa-${type === 'success' ? 'check-circle' : type === 'error' ? 'exclamation-circle' : 'info-circle'}"></i>
        <span>${message}</span>
    `;

    toastContainer.appendChild(toast);

    setTimeout(() => {
        toast.remove();
    }, 3000);
}

// ===== Data Management Functions =====
function loadUserData() {
    const savedData = localStorage.getItem('mindfixData');
    if (savedData) {
        AppState.userData = JSON.parse(savedData);
        updateTriggersCount();
        updateDashboard();
        updateTrendsChart();
        updateCalendar();
        updateGoalsProgress();
        checkAlerts();
    }
}

function saveUserData() {
    localStorage.setItem('mindfixData', JSON.stringify(AppState.userData));
}

function clearAllData() {
    if (confirm('Are you sure you want to clear all data? This cannot be undone.')) {
        localStorage.removeItem('mindfixData');
        AppState.userData = {
            dailyEntries: [],
            journalEntries: {},
            settings: AppState.userData.settings
        };
        updateDashboard();
        updateTrendsChart();
        updateCalendar();
        updateGoalsProgress();
        showToast('All data has been cleared', 'success');
    }
}

function exportData() {
    const dataStr = JSON.stringify(AppState.userData, null, 2);
    const dataUri = 'data:application/json;charset=utf-8,' + encodeURIComponent(dataStr);
    const exportFileDefaultName = `mindfix-data-${getDateKey(new Date())}.json`;

    const linkElement = document.createElement('a');
    linkElement.setAttribute('href', dataUri);
    linkElement.setAttribute('download', exportFileDefaultName);
    linkElement.click();
    showToast('Data exported successfully', 'success');
}

// ===== Stress Score Calculation =====
function calculateStressScore(formData) {
    let score = 0;

    // Mood calculation (1=high stress, 5=low stress)
    const moodScore = (6 - formData.mood) * 10; // Converts 1-5 to 50-10
    score += moodScore;

    // Sleep quality
    if (formData.sleep === 'poor') score += 20;
    else if (formData.sleep === 'average') score += 10;

    // Study pressure
    if (formData.study === 'high') score += 25;
    else if (formData.study === 'medium') score += 15;

    // Screen time
    if (formData.screen === 'high') score += 15;
    else if (formData.screen === 'medium') score += 10;

    // Triggers
    score += formData.triggers.length * 10;

    // Cap at 100
    return Math.min(score, 100);
}

function getStressLevel(score) {
    if (score <= 30) return AppState.stressLevels.calm;
    if (score <= 60) return AppState.stressLevels.moderate;
    return AppState.stressLevels.high;
}

// ===== Dashboard Functions =====
function updateDashboard() {
    // Update date
    currentDateEl.textContent = formatDate(AppState.currentDate);

    // Update streak
    const streak = calculateStreak();
    streakCountEl.textContent = streak;

    // Update today's stress score if available
    const todayKey = getDateKey(AppState.currentDate);
    const todayEntry = AppState.userData.dailyEntries.find(entry => entry.date === todayKey);

    if (todayEntry) {
        AppState.currentStressScore = todayEntry.stressScore;
        const stressLevel = getStressLevel(AppState.currentStressScore);

        // Update score display
        document.querySelector('.score-circle').textContent = AppState.currentStressScore;
        document.querySelector('.score-circle').style.backgroundColor = stressLevel.color;
        document.querySelector('.stress-status').textContent = stressLevel.label;

        // Update meter
        meterFillEl.style.width = `${AppState.currentStressScore}%`;

        // Update daily tip
        const tips = AppState.copingTips[stressLevel.label.toLowerCase()];
        dailyTipEl.textContent = tips[Math.floor(Math.random() * tips.length)];
    } else {
        document.querySelector('.score-circle').textContent = '--';
        document.querySelector('.stress-status').textContent = 'No data yet';
        meterFillEl.style.width = '0%';
        dailyTipEl.textContent = 'Complete your daily check-in to get personalized tips.';
    }

    // Update top triggers
    updateTopTriggers();
}

function calculateStreak() {
    if (AppState.userData.dailyEntries.length === 0) return 0;

    const sortedEntries = [...AppState.userData.dailyEntries]
        .sort((a, b) => new Date(b.date) - new Date(a.date));

    let streak = 0;
    let currentDate = new Date();

    // Check consecutive days from today backwards
    for (let i = 0; i < sortedEntries.length; i++) {
        const entryDate = new Date(sortedEntries[i].date);
        const diffTime = currentDate - entryDate;
        const diffDays = Math.floor(diffTime / (1000 * 60 * 60 * 24));

        if (diffDays === i) {
            streak++;
        } else {
            break;
        }
    }

    return streak;
}

function updateTriggersCount() {
    // Reset counts
    AppState.triggers.forEach(trigger => trigger.count = 0);

    // Count triggers from all entries
    AppState.userData.dailyEntries.forEach(entry => {
        entry.triggers.forEach(triggerId => {
            const trigger = AppState.triggers.find(t => t.id === triggerId);
            if (trigger) trigger.count++;
        });
    });
}

function updateTopTriggers() {
    topTriggersEl.innerHTML = '';

    const sortedTriggers = [...AppState.triggers]
        .filter(trigger => trigger.count > 0)
        .sort((a, b) => b.count - a.count)
        .slice(0, 3);

    if (sortedTriggers.length === 0) {
        topTriggersEl.innerHTML = '<li>No triggers recorded yet</li>';
        return;
    }

    sortedTriggers.forEach(trigger => {
        const li = document.createElement('li');
        li.innerHTML = `
            <i class="fas fa-bolt"></i>
            <span>${trigger.name}</span>
            <span class="trigger-count">(${trigger.count} times)</span>
        `;
        topTriggersEl.appendChild(li);
    });
}

// ===== Check-in Form Functions =====
function setupCheckinForm() {
    // Mood slider
    moodSlider.addEventListener('input', function() {
        moodValueEl.textContent = this.value;
        updatePreview();
    });

    // Option buttons
    setupOptionButtons(sleepButtons, 'sleepQuality');
    setupOptionButtons(studyButtons, 'studyPressure');
    setupOptionButtons(screenButtons, 'screenTime');

    // Trigger checkboxes
    triggerCheckboxes.forEach(checkbox => {
        checkbox.addEventListener('change', updatePreview);
    });

    // Notes
    dailyNotesEl.addEventListener('input', updatePreview);

    // Form submission
    checkinForm.addEventListener('submit', handleFormSubmit);

    // Reset form
    resetFormBtn.addEventListener('click', resetForm);

    // Quick check-in button
    quickCheckinBtn.addEventListener('click', () => {
        document.querySelector('#checkin').scrollIntoView({ behavior: 'smooth' });
    });
}

function setupOptionButtons(buttons, inputId) {
    buttons.forEach(button => {
        button.addEventListener('click', function() {
            const value = this.getAttribute('data-value');

            // Update active state
            buttons.forEach(btn => btn.classList.remove('active'));
            this.classList.add('active');

            // Update hidden input
            document.getElementById(inputId).value = value;

            updatePreview();
        });
    });
}

function updatePreview() {
    const mood = parseInt(moodSlider.value);
    const sleep = document.getElementById('sleepQuality').value;
    const study = document.getElementById('studyPressure').value;
    const screen = document.getElementById('screenTime').value;

    // Get selected triggers
    const selectedTriggers = [];
    triggerCheckboxes.forEach(checkbox => {
        if (checkbox.checked) selectedTriggers.push(checkbox.value);
    });

    // Update preview values
    previewMoodEl.textContent = `${mood}/5`;
    previewSleepEl.textContent = sleep.charAt(0).toUpperCase() + sleep.slice(1);
    previewStudyEl.textContent = study.charAt(0).toUpperCase() + study.slice(1);
    previewScreenEl.textContent = screen.charAt(0).toUpperCase() + screen.slice(1);
    previewTriggersEl.textContent = selectedTriggers.length > 0 ?
        selectedTriggers.length + ' selected' :
        'None';

    // Calculate and update stress preview
    const formData = {
        mood,
        sleep,
        study,
        screen,
        triggers: selectedTriggers
    };

    const stressScore = calculateStressScore(formData);
    const stressLevel = getStressLevel(stressScore);

    previewStressEl.textContent = `${stressScore} (${stressLevel.label})`;
    previewStressEl.style.color = stressLevel.color;
}

function handleFormSubmit(e) {
    e.preventDefault();

    const todayKey = getDateKey(AppState.currentDate);

    // Check if entry already exists for today
    const existingIndex = AppState.userData.dailyEntries.findIndex(entry => entry.date === todayKey);

    // Get form values
    const mood = parseInt(moodSlider.value);
    const sleep = document.getElementById('sleepQuality').value;
    const study = document.getElementById('studyPressure').value;
    const screen = document.getElementById('screenTime').value;
    const notes = dailyNotesEl.value;

    // Get selected triggers
    const selectedTriggers = [];
    triggerCheckboxes.forEach(checkbox => {
        if (checkbox.checked) selectedTriggers.push(checkbox.value);
    });

    // Calculate stress score
    const formData = { mood, sleep, study, screen, triggers: selectedTriggers };
    const stressScore = calculateStressScore(formData);

    // Create entry object
    const entry = {
        date: todayKey,
        mood,
        sleep,
        study,
        screen,
        triggers: selectedTriggers,
        notes,
        stressScore
    };

    // Update or add entry
    if (existingIndex !== -1) {
        AppState.userData.dailyEntries[existingIndex] = entry;
        showToast('Today\'s check-in updated successfully', 'success');
    } else {
        AppState.userData.dailyEntries.push(entry);
        showToast('Daily check-in saved successfully', 'success');
    }

    // Save data
    saveUserData();

    // Update UI
    updateDashboard();
    updateTrendsChart();
    updateCalendar();
    updateGoalsProgress();
    checkAlerts();

    // Reset form
    resetForm();
}

function resetForm() {
    moodSlider.value = 3;
    moodValueEl.textContent = '3';

    // Reset option buttons
    document.querySelectorAll('.option-btn').forEach(btn => {
        btn.classList.remove('active');
        if (btn.getAttribute('data-value') === 'average' || btn.getAttribute('data-value') === 'medium') {
            btn.classList.add('active');
        }
    });

    document.getElementById('sleepQuality').value = 'average';
    document.getElementById('studyPressure').value = 'medium';
    document.getElementById('screenTime').value = 'medium';

    // Reset checkboxes
    triggerCheckboxes.forEach(checkbox => checkbox.checked = false);

    // Reset notes
    dailyNotesEl.value = '';

    // Update preview
    updatePreview();
}

// ===== Trends & Calendar Functions =====
function updateTrendsChart() {
    // Implementation for Chart.js graph
    // This would create a line chart of stress scores over time
}

function updateCalendar() {
    // Implementation for calendar heatmap
    // This would generate a calendar grid with colored days based on stress scores
}

// ===== Pattern Analysis Functions =====
function analyzePatterns() {
    patternsListEl.innerHTML = '';

    if (AppState.userData.dailyEntries.length < 3) {
        patternsListEl.innerHTML = `
            <div class="pattern-item">
                <i class="fas fa-info-circle"></i>
                <p>Complete at least 3 daily check-ins to see your patterns</p>
            </div>
        `;
        return;
    }

    // Analyze patterns
    const patterns = detectPatterns();

    if (patterns.length === 0) {
        patternsListEl.innerHTML = `
            <div class="pattern-item">
                <i class="fas fa-info-circle"></i>
                <p>No significant patterns detected yet. Keep tracking your data!</p>
            </div>
        `;
        return;
    }

    // Display patterns
    patterns.forEach(pattern => {
        const patternItem = document.createElement('div');
        patternItem.className = 'pattern-item';
        patternItem.innerHTML = `
            <i class="fas fa-${pattern.icon}"></i>
            <p><strong>${pattern.title}:</strong> ${pattern.description}</p>
        `;
        patternsListEl.appendChild(patternItem);
    });
}

function detectPatterns() {
    const patterns = [];

    // Analyze last 7 entries
    const recentEntries = [...AppState.userData.dailyEntries]
        .sort((a, b) => new Date(b.date) - new Date(a.date))
        .slice(0, 7);

    if (recentEntries.length < 3) return patterns;

    // Pattern 1: High stress after poor sleep
    const poorSleepHighStress = recentEntries.filter(entry =>
        entry.sleep === 'poor' && entry.stressScore >= 60
    ).length;

    if (poorSleepHighStress >= 2) {
        patterns.push({
            icon: 'bed',
            title: 'Sleep-Stress Connection',
            description: 'You frequently experience high stress after poor sleep. Consider improving sleep hygiene.'
        });
    }

    // Pattern 2: Stress peaks on weekdays
    const weekdayEntries = recentEntries.filter(entry => {
        const date = new Date(entry.date);
        const day = date.getDay();
        return day >= 1 && day <= 5; // Monday to Friday
    });

    const weekendEntries = recentEntries.filter(entry => {
        const date = new Date(entry.date);
        const day = date.getDay();
        return day === 0 || day === 6; // Saturday or Sunday
    });

    if (weekdayEntries.length > 0 && weekendEntries.length > 0) {
        const avgWeekdayStress = weekdayEntries.reduce((sum, entry) => sum + entry.stressScore, 0) / weekdayEntries.length;
        const avgWeekendStress = weekendEntries.reduce((sum, entry) => sum + entry.stressScore, 0) / weekendEntries.length;

        if (avgWeekdayStress - avgWeekendStress > 15) {
            patterns.push({
                icon: 'calendar',
                title: 'Weekday Stress',
                description: 'Your stress levels are significantly higher on weekdays. Consider stress management techniques during work/school days.'
            });
        }
    }

    // Pattern 3: Continuous high-stress streak
    let highStressStreak = 0;
    let currentStreak = 0;

    recentEntries.forEach(entry => {
        if (entry.stressScore >= 60) {
            currentStreak++;
            highStressStreak = Math.max(highStressStreak, currentStreak);
        } else {
            currentStreak = 0;
        }
    });

    if (highStressStreak >= 3) {
        patterns.push({
            icon: 'exclamation-triangle',
            title: 'Extended High Stress',
            description: `You've had ${highStressStreak} consecutive days of high stress. Consider taking proactive steps to reduce stress.`
        });
    }

    return patterns;
}

// ===== Timer Functions =====
function setupTimer() {
    startTimerBtn.addEventListener('click', startTimer);
    pauseTimerBtn.addEventListener('click', pauseTimer);
    resetTimerBtn.addEventListener('click', resetTimer);

    focusTimeInput.addEventListener('change', function() {
        AppState.userData.settings.focusTime = parseInt(this.value);
        if (!AppState.timer.isRunning) {
            timerMinutesEl.textContent = this.value.padStart(2, '0');
        }
        saveUserData();
    });

    breakTimeInput.addEventListener('change', function() {
        AppState.userData.settings.breakTime = parseInt(this.value);
        saveUserData();
    });

    // Load settings
    focusTimeInput.value = AppState.userData.settings.focusTime;
    breakTimeInput.value = AppState.userData.settings.breakTime;
}

function startTimer() {
    if (AppState.timer.isRunning) return;

    AppState.timer.isRunning = true;
    AppState.timer.intervalId = setInterval(updateTimer, 1000);

    startTimerBtn.disabled = true;
    pauseTimerBtn.disabled = false;

    showToast(`${AppState.timer.isFocusTime ? 'Focus' : 'Break'} timer started`, 'success');
}

function pauseTimer() {
    if (!AppState.timer.isRunning) return;

    clearInterval(AppState.timer.intervalId);
    AppState.timer.isRunning = false;

    startTimerBtn.disabled = false;
    pauseTimerBtn.disabled = true;

    showToast('Timer paused', 'info');
}

function resetTimer() {
    clearInterval(AppState.timer.intervalId);

    AppState.timer.isRunning = false;
    AppState.timer.isFocusTime = true;
    AppState.timer.minutes = AppState.userData.settings.focusTime;
    AppState.timer.seconds = 0;

    updateTimerDisplay();
    timerModeEl.textContent = 'Focus Time';

    startTimerBtn.disabled = false;
    pauseTimerBtn.disabled = true;

    showToast('Timer reset', 'info');
}

function updateTimer() {
    if (AppState.timer.seconds > 0) {
        AppState.timer.seconds--;
    } else if (AppState.timer.minutes > 0) {
        AppState.timer.minutes--;
        AppState.timer.seconds = 59;
    } else {
        // Timer completed
        clearInterval(AppState.timer.intervalId);
        AppState.timer.isRunning = false;

        // Switch mode
        AppState.timer.isFocusTime = !AppState.timer.isFocusTime;

        if (AppState.timer.isFocusTime) {
            AppState.timer.minutes = AppState.userData.settings.focusTime;
            timerModeEl.textContent = 'Focus Time';
            showToast('Focus time complete! Time for a break?', 'success');
        } else {
            AppState.timer.minutes = AppState.userData.settings.breakTime;
            timerModeEl.textContent = 'Break Time';
            showToast('Break time complete! Ready to focus?', 'success');
        }

        AppState.timer.seconds = 0;

        startTimerBtn.disabled = false;
        pauseTimerBtn.disabled = true;

        // Start next session automatically
        setTimeout(startTimer, 2000);
    }

    updateTimerDisplay();
}

function updateTimerDisplay() {
    timerMinutesEl.textContent = AppState.timer.minutes.toString().padStart(2, '0');
    timerSecondsEl.textContent = AppState.timer.seconds.toString().padStart(2, '0');
}

// ===== Breathing Exercise Functions =====
function setupBreathingExercise() {
    startBreathingBtn.addEventListener('click', startBreathing);
    stopBreathingBtn.addEventListener('click', stopBreathing);
}

function startBreathing() {
    if (AppState.breathing.isActive) return;

    AppState.breathing.isActive = true;
    AppState.breathing.isInhaling = true;

    breathingCircleEl.style.transform = 'scale(1.5)';
    breathTextEl.textContent = 'Breathe In';

    // Alternate between inhale and exhale every 4 seconds
    AppState.breathing.intervalId = setInterval(() => {
        if (AppState.breathing.isInhaling) {
            breathingCircleEl.style.transform = 'scale(1)';
            breathTextEl.textContent = 'Breathe Out';
        } else {
            breathingCircleEl.style.transform = 'scale(1.5)';
            breathTextEl.textContent = 'Breathe In';
        }

        AppState.breathing.isInhaling = !AppState.breathing.isInhaling;
    }, 4000);

    startBreathingBtn.disabled = true;
    stopBreathingBtn.disabled = false;

    showToast('Breathing exercise started. Follow the circle.', 'success');
}

function stopBreathing() {
    if (!AppState.breathing.isActive) return;

    clearInterval(AppState.breathing.intervalId);
    AppState.breathing.isActive = false;

    breathingCircleEl.style.transform = 'scale(1)';
    breathTextEl.textContent = 'Breathe In';

    startBreathingBtn.disabled = false;
    stopBreathingBtn.disabled = true;

    showToast('Breathing exercise stopped', 'info');
}

// ===== Report & Goals Functions =====
function setupReportsAndGoals() {
    generateReportBtn.addEventListener('click', generateWeeklyReport);
    exportReportBtn.addEventListener('click', exportWeeklyReport);
    updateGoalsBtn.addEventListener('click', updateGoalsProgress);
    saveJournalBtn.addEventListener('click', saveJournalEntry);
    viewJournalBtn.addEventListener('click', viewJournalEntries);
}

function generateWeeklyReport() {
    // Get entries from the last 7 days
    const oneWeekAgo = new Date();
    oneWeekAgo.setDate(oneWeekAgo.getDate() - 7);

    const weeklyEntries = AppState.userData.dailyEntries.filter(entry => {
        const entryDate = new Date(entry.date);
        return entryDate >= oneWeekAgo;
    });

    if (weeklyEntries.length < 2) {
        reportMessageEl.textContent = 'Complete at least 2 daily check-ins this week to generate a report.';
        return;
    }

    // Calculate statistics
    const stressScores = weeklyEntries.map(entry => entry.stressScore);
    const avgStress = stressScores.reduce((sum, score) => sum + score, 0) / stressScores.length;

    const bestDayEntry = weeklyEntries.reduce((best, entry) =>
        entry.stressScore < best.stressScore ? entry : best
    );

    const worstDayEntry = weeklyEntries.reduce((worst, entry) =>
        entry.stressScore > worst.stressScore ? entry : worst
    );

    // Determine trend
    let trend = 'Stable';
    if (weeklyEntries.length >= 3) {
        const firstHalfAvg = weeklyEntries.slice(0, Math.floor(weeklyEntries.length / 2))
            .reduce((sum, entry) => sum + entry.stressScore, 0) / Math.floor(weeklyEntries.length / 2);

        const secondHalfAvg = weeklyEntries.slice(Math.floor(weeklyEntries.length / 2))
            .reduce((sum, entry) => sum + entry.stressScore, 0) / Math.ceil(weeklyEntries.length / 2);

        if (secondHalfAvg - firstHalfAvg > 10) trend = 'Increasing';
        else if (firstHalfAvg - secondHalfAvg > 10) trend = 'Decreasing';
    }

    // Update UI
    avgStressEl.textContent = avgStress.toFixed(1);
    bestDayEl.textContent = `${bestDayEntry.date} (${bestDayEntry.stressScore})`;
    worstDayEl.textContent = `${worstDayEntry.date} (${worstDayEntry.stressScore})`;
    stressTrendEl.textContent = trend;

    // Generate message
    let message = `Your average stress level this week was ${avgStress.toFixed(1)}. `;

    if (avgStress <= 30) {
        message += "You're doing great at managing stress!";
    } else if (avgStress <= 60) {
        message += "Consider incorporating more stress-relief activities.";
    } else {
        message += "Your stress levels are high. Please consider seeking support or trying our breathing exercises.";
    }

    reportMessageEl.textContent = message;
    showToast('Weekly report generated', 'success');
}

function exportWeeklyReport() {
    // Implementation for exporting report as text file
    showToast('Report export feature coming soon', 'info');
}

function updateGoalsProgress() {
    // Implementation for updating goal progress bars
    // This would calculate progress based on weekly data
    showToast('Goals updated', 'success');
}

function saveJournalEntry() {
    const todayKey = getDateKey(AppState.currentDate);
    const entry = journalEntryEl.value.trim();

    if (entry === '') {
        showToast('Journal entry cannot be empty', 'error');
        return;
    }

    AppState.userData.journalEntries[todayKey] = {
        date: todayKey,
        content: entry,
        timestamp: new Date().toISOString()
    };

    saveUserData();
    journalEntryEl.value = '';
    showToast('Journal entry saved', 'success');
}

function viewJournalEntries() {
    // Implementation for viewing past journal entries
    showToast('Journal viewer coming soon', 'info');
}

function checkAlerts() {
    alertsListEl.innerHTML = '';

    // Check for high stress streaks
    const recentEntries = [...AppState.userData.dailyEntries]
        .sort((a, b) => new Date(b.date) - new Date(a.date))
        .slice(0, 3);

    if (recentEntries.length >= 3 && recentEntries.every(entry => entry.stressScore >= 60)) {
        const alertItem = document.createElement('div');
        alertItem.className = 'alert-item';
        alertItem.innerHTML = `
            <i class="fas fa-exclamation-triangle"></i>
            <span>3 consecutive high-stress days detected. Consider taking action.</span>
        `;
        alertsListEl.appendChild(alertItem);
    }

    // Check for missed check-ins
    const today = new Date();
    const yesterday = new Date(today);
    yesterday.setDate(yesterday.getDate() - 1);
    const yesterdayKey = getDateKey(yesterday);

    const hasYesterdayEntry = AppState.userData.dailyEntries.some(entry => entry.date === yesterdayKey);
    const hasTodayEntry = AppState.userData.dailyEntries.some(entry => entry.date === getDateKey(today));

    if (!hasYesterdayEntry && !hasTodayEntry && AppState.userData.dailyEntries.length > 0) {
        const alertItem = document.createElement('div');
        alertItem.className = 'alert-item';
        alertItem.innerHTML = `
            <i class="fas fa-calendar-times"></i>
            <span>You missed yesterday's check-in. Consistency helps detect patterns.</span>
        `;
        alertsListEl.appendChild(alertItem);
    }

    // If no alerts
    if (alertsListEl.children.length === 0) {
        alertsListEl.innerHTML = `
            <div class="alert-item">
                <i class="fas fa-info-circle"></i>
                <span>No alerts at the moment</span>
            </div>
        `;
    }
}

// ===== Theme & UI Functions =====
function setupTheme() {
    darkModeToggle.addEventListener('click', toggleDarkMode);

    // Check system preference
    const prefersDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
    const savedTheme = AppState.userData.settings.darkMode;

    if (savedTheme !== undefined) {
        if (savedTheme) document.body.classList.add('dark-theme');
    } else if (prefersDark) {
        document.body.classList.add('dark-theme');
        AppState.userData.settings.darkMode = true;
        saveUserData();
    }

    updateThemeIcon();
}

function toggleDarkMode() {
    document.body.classList.toggle('dark-theme');
    AppState.userData.settings.darkMode = document.body.classList.contains('dark-theme');
    saveUserData();
    updateThemeIcon();
    showToast(`Dark mode ${AppState.userData.settings.darkMode ? 'enabled' : 'disabled'}`, 'success');
}

function updateThemeIcon() {
    const icon = darkModeToggle.querySelector('i');
    if (document.body.classList.contains('dark-theme')) {
        icon.className = 'fas fa-sun';
    } else {
        icon.className = 'fas fa-moon';
    }
}

// ===== Initialize Application =====
function initializeApp() {
    // Load saved data
    loadUserData();

    // Setup all components
    setupCheckinForm();
    setupTimer();
    setupBreathingExercise();
    setupReportsAndGoals();
    setupTheme();

    // Initialize UI
    updateDashboard();
    updatePreview();
    analyzePatterns();
    checkAlerts();

    // Setup event listeners for data management
    clearDataBtn.addEventListener('click', clearAllData);
    exportAllBtn.addEventListener('click', exportData);
    analyzePatternsBtn.addEventListener('click', analyzePatterns);

    // Auto-check for alerts every hour
    setInterval(checkAlerts, 60 * 60 * 1000);

    showToast('MindFix loaded successfully!', 'success');
}

// Start the application when DOM is loaded
document.addEventListener('DOMContentLoaded', initializeApp);